=======
Credits
=======

Development Lead
----------------

* Boris Gailleton <b.gailleton@sms.ed.ac.uk>

Contributors
------------

* Python development: Boris Gailleton

* Cpp lsdtopotools: Simon M. Mudd (lead dev.), (unordered) Dave T. Miladowski, Stuart Grieves, Fiona J. Clubb, Declan Valters, Boris Gailleton

* lsdtopytools alpha tester: Emma Graf, Jorien Van Der Hoeven, Rebbeca Harries, Arturo Tamay 
